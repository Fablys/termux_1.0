chmod 7777 cons.sh
tsudo mv /data/data/com.termux/files/home/termux_1.0/GWC/config/qwerty /data/data/com.termux/files/usr/bin
tsudo mv /data/data/com.termux/files/home/termux_1.0/GWC/config/uuu /data/data/com.termux/files/usr/bin
tsudo mv /data/data/com.termux/files/home/termux_1.0/GWC/config/uuu2 /data/data/com.termux/files/usr/bin
tsudo mv /data/data/com.termux/files/home/termux_1.0/GWC/config/uuu3 /data/data/com.termux/files/usr/bin
tsudo chmod 7777 /data/data/com.termux/files/usr/bin/qwerty
tsudo chmod 7777 /data/data/com.termux/files/usr/bin/uuu
tsudo chmod 7777 /data/data/com.termux/files/usr/bin/uuu2
tsudo chmod 7777 /data/data/com.termux/files/usr/bin/uuu3
tsudo cp /data/data/com.tencent.ig/lib/libtprt.so /data/data/com.termux/files/home/GWC/orig
tsudo cp /data/data/com.tencent.ig/lib/libUE4.so /data/data/com.termux/files/home/GWC/orig
tsudo cp /data/data/com.tencent.ig/lib/libgcloud.so /data/data/com.termux/files/home/GWC/orig
tsudo cp /data/data/com.tencent.ig/lib/libtersafe.so /data/data/com.termux/files/home/GWC/orig
